
import { Players } from "@rbxts/services"
import { makeHello } from "shared/module";

interface PlayerObject {
    [key: string]: object | number;
}

let PlayerGroup: PlayerObject = {}

print(makeHello("main.server.ts"));

const voidtest = () => {
    print("voidtest")
}


Players.PlayerAdded.Connect((player : Player) => {

    print(`Hello, ${player}!`)

    PlayerGroup[player.Name] = player

    voidtest()
})

